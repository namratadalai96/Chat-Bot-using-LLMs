from app import app, db
from views import *


if __name__ == '__main__':
    app.run()
