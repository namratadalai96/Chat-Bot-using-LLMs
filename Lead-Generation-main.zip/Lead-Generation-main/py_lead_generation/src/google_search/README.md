empty for now
but in the foreseeable future
i will finish it
using playwright and regex
to scrape google search results urls
locate leads information on them
and export it to csv
most importantly here
is the regex
which is complex
bb for now
