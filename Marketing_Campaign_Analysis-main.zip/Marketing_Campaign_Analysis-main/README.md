# Data Science Project

## Marketing Campaign Analysis

Dataset: https://github.com/nailson/ifood-data-business-analyst-test

Challenge: A food store has various campaigns going on to maximize the profit. They want to find out Customer response prediction (how many of them will accept the latest campaign), purchasing behavior, campaign interactions, customer segmentation, customer lifetime value, etc.

## Tech Stack:
* PySpark
* Spark ML
* Python
* Jupyter
